bool isTrackForward(Track::TrackObject@ obj)
{
    return !Track::isReverse();
}

bool isTrackReverse(Track::TrackObject@ obj)
{
    return Track::isReverse();
}
