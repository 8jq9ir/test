bool isTrackReverse(Track::TrackObject@ obj)
{
    return !Track::isReverse();
}
bool lol(Track::TrackObject@ obj)
{
    return Track::isReverse();
}