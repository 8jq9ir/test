bool isReverse(Track::TrackObject@ obj)
{
    return Track::isReverse();
}
bool isForward(Track::TrackObject@ obj)
{
    return !Track::isReverse();
}
void knock(int idKart, const string libraryInstance, const string obj_id) {
	Kart::squash(idKart, 2.0);
}
