bool isTReverse(Track::TrackObject@ obj)
{
    return Track::isReverse();
}

bool isTForward(Track::TrackObject@ obj)
{
    return !Track::isReverse();
}