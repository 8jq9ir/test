bool isReverse(Track::TrackObject@ obj)
{
    return Track::isReverse();
}
